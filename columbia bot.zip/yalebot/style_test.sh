#!/usr/bin/env bash
# E501 Line too long
pycodestyle *.py modules/* --ignore=E501
